<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            text-align: center;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .border {
            border: 2px solid #333;
            padding: 10px;
            background-color: #FF6600;
        }

        .box {
            display: inline-block;
            padding: 20px 30px;
            margin: 10px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .box:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div>
        <h1 class="border">Choose Panel</h1>
    </div>
    <div class="container">
        <a class="box" href="floor.php">Floor Advertisements</a>
        <a class="box" href="shop.php">Shop Advertisements</a>
        <a class="box" href="wall.php">Wall Advertisements</a>
    </div>
</body>
</html>
