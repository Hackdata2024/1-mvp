<!DOCTYPE html>
<html>
<head>
    <title>Advertisement Panel</title>
      <style>
          /* style.css */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

h1 {
    background-color: #ff6600;
    color: yellow;
    text-align: center;
    padding: 20px;
}

table {
    margin: 20px auto;
    background-color: #fff;
    border-collapse: collapse;
    width: 80%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: center;
}

th {
    background-color: #ff6600;
    color: #fff;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

input[type="file"] {
    width: 100%;
    padding: 10px;
    margin: 0;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    background-color: #ff6600;
    color: #fff;
    border: none;
    border-radius: 3px;
    padding: 10px 20px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #ff3300;
}

/* Add more styles as needed */

      </style>
</head>
<body>
    <h1> Wall Advertisments </h1>
    <form method="post" enctype="multipart/form-data">
        <table>
        <?php
$wallFolder = 'img';

for ($i = 1; $i <= 6; $i++) {
    $wallName = "wall$i.png"; // Change the format to PNG
    $wallPath = "$wallFolder/$wallName";
    $uploadError = ''; // Initialize error message as empty
    $labelText = "Wall Panel $i";

    if (isset($_FILES["wall$i"])) {
        $fileExtension = pathinfo($_FILES["wall$i"]["name"], PATHINFO_EXTENSION);

        if ($fileExtension != 'png') {
            $uploadError = 'Invalid file format. Please upload a PNG wall.';
        } else {
            if (move_uploaded_file($_FILES["wall$i"]["tmp_name"], $wallPath)) {
                $uploadError = 'Replaced';
            } else {
                $uploadError = 'Failed to replace';
            }
        }
    }

    echo "<tr>";
    echo "<td>$labelText:</td>";
    echo "<td><input type='file' name='wall$i'></td>";
    echo "<td><input type='submit' value='Upload' name='submit$i'></td>";
    echo "<td>$uploadError</td>";
    echo "</tr>";

    // Reset the error message for the next iteration
    $uploadError = '';
}
?>

        </table>
        <center><input type="submit" value="Replace walls" name="submit_all"></center>
        <br>
    </form>
</body>
</html>
