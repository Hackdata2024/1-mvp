<?php
$namey = basename(__DIR__);

$folderPath = 'image/';
$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

if (is_dir($folderPath)) {
    $files = scandir($folderPath);
    $imageCount = 0;

    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $path_parts = pathinfo($folderPath . $file);
            $extension = strtolower($path_parts['extension']);

            if (in_array($extension, $allowedExtensions) && is_file($folderPath . $file)) {
                $imageCount++;
            }
        }
    }

    $images = glob($folderPath . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Image Gallery</title>
  <style>
    @import url("https://fonts.googleapis.com/css?family=Quicksand:400,500,700&subset=latin-ext");

    html {
      position: relative;
      overflow-x: hidden !important;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: "Quicksand", sans-serif;
      color: #324e63;
    }

    a,
    a:hover {
      text-decoration: none;
    }

    .icon {
      display: inline-block;
      width: 1em;
      height: 1em;
      stroke-width: 0;
      stroke: currentColor;
      fill: currentColor;
    }

    .wrapper {
      width: 100%;
      width: 100%;
      height: auto;
      min-height: 100vh;
      padding: 50px 20px;
      padding-top: 100px;
      display: flex;
      background-image: linear-gradient(-20deg, #ff2846 0%, #6944ff 100%);
      display: flex;
      background-image: linear-gradient(-20deg, #ff2846 0%, #6944ff 100%);
    }

    @media screen and (max-width: 768px) {
      .wrapper {
        height: auto;
        min-height: 100vh;
        padding-top: 100px;
      }
    }

    .profile-card {
      width: 100%;
      min-height: 460px;
      margin: auto;
      box-shadow: 0px 8px 60px -10px rgba(13, 28, 39, 0.6);
      background: #fff;
      border-radius: 12px;
      max-width: 700px;
      position: relative;
    }

    .profile-card.active .profile-card__cnt {
      filter: blur(6px);
    }

    .profile-card.active,
    .profile-card.active {
      opacity: 1;
      pointer-events: auto;
      transition-delay: 0.1s;
    }

    .profile-card.active {
      transform: none;
      transition-delay: 0.1s;
    }

    .profile-card__img {
      width: 150px;
      height: 150px;
      margin-left: auto;
      margin-right: auto;
      transform: translateY(-50%);
      border-radius: 50%;
      overflow: hidden;
      position: relative;
    
      box-shadow: 0px 5px 50px 0px #6c44fc, 0px 0px 0px 7px rgba(107, 74, 255, 0.5);
    }

    @media screen and (max-width: 576px) {
      .profile-card__img {
        width: 120px;
        height: 120px;
      }
    }

    .profile-card__img img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 50%;
    }

    .profile-card__cnt {
      margin-top: -35px;
      text-align: center;
      padding: 0 20px;
      padding-bottom: 40px;
      transition: all 0.3s;
    }

    .profile-card__name {
      font-weight: 700;
      font-size: 24px;
      color: #6944ff;
      margin-bottom: 15px;
    }




    .profile-card-inf {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      align-items: flex-start;
      margin-top: 35px;
    }

    .profile-card-inf__item {
      padding: 10px 35px;
      min-width: 150px;
    }

    @media screen and (max-width: 768px) {
      .profile-card-inf__item {
        padding: 10px 20px;
        min-width: 120px;
      }
    }

    .profile-card-inf__title {
      font-weight: 700;
      font-size: 27px;
      color: #324e63;
    }

    .profile-card-inf__txt {
      font-weight: 500;
      margin-top: 7px;
    }

    .profile-card-social__item {
      display: inline-flex;
      width: 55px;
      height: 55px;
      margin: 15px;
      border-radius: 50%;
      align-items: center;
      justify-content: center;
      color: #fff;
      background: #405de6;
      box-shadow: 0px 7px 30px rgba(43, 98, 169, 0.5);
      position: relative;
      font-size: 21px;
      flex-shrink: 0;
      transition: all 0.3s;
    }
    .profile-card textarea {
      width: 100%;
      resize: none;
      height: 210px;
      margin-bottom: 20px;
      border: 2px solid #dcdcdc;
      border-radius: 10px;
      padding: 15px 20px;
      color: #324e63;
      font-weight: 500;
      font-family: "Quicksand", sans-serif;
      outline: none;
      transition: all 0.3s;
    }

    .profile-card textarea:focus {
      outline: none;
      border-color: #8a979e;
    }
    .image-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}

.grid-item {
  width: 100%;
  overflow: hidden;
  border-radius: 8px;
}

.grid-item img {
  width: 100%;
  height: auto;
  display: block;
}
.popup {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    justify-content: center;
    align-items: center;
  }

  .popup img {
    max-width: 80%;
    max-height: 80%;
  }

  .popup-close {
    position: absolute;
    top: 20px;
    right: 20px;
    color: white;
    font-size: 50px;
    cursor: pointer;
  }
  .clickbtn{
display: grid;
margin-top: -100px;
margin-left: -5px;
margin-bottom: 50px;
border-radius: 5px;
font-weight: 400;
    font-size: 18px;
    color: #6944ff;


  }
  a{
    text-decoration: none;
  }
  </style>
</head>

<body>

<div class="wrapper">
  <div class="profile-card js-profile-card">
    <div class="profile-card__img">
      <img src="https://twis.in/shop/hackdata/img.jpg" alt="profile card">
    </div>

    <div class="profile-card__cnt js-profile-cnt">
    <a href="../../search.php">  <button class="clickbtn">Back </button></a>
      <div class="profile-card__name"><?php echo "$namey"; ?></div>

      <div class="profile-card-inf">
        <div class="profile-card-inf__item">
          <div class="profile-card-inf__title"><?php echo "$imageCount"; ?></div>
          <div class="profile-card-inf__txt">Posts</div>
        </div>

        <div class="image-grid">
          <?php
          foreach ($images as $image) {
              echo '<div class="grid-item">';
              echo '<img src="' . $image . '" alt="Image">';
              echo '</div>';
          }
          ?>
          <div class="popup" id="imagePopup">
  <span class="popup-close" id="popupClose">&times;</span>
  <img id="popupImage" alt="Enlarged Image">
</div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  
  document.addEventListener('DOMContentLoaded', function () {
    var popup = document.getElementById('imagePopup');
    var popupImage = document.getElementById('popupImage');

    // Function to open the popup
    function openPopup(src) {
      popupImage.src = src;
      popup.style.display = 'flex';
    }

    // Function to close the popup
    function closePopup() {
      popup.style.display = 'none';
    }

    // Attach a click event to each image to open the popup
    var images = document.querySelectorAll('.grid-item img');
    images.forEach(function (image) {
      image.addEventListener('click', function () {
        openPopup(image.src);
      });
    });

    // Close popup when the close button is clicked
    var closeBtn = document.getElementById('popupClose');
    closeBtn.addEventListener('click', closePopup);
  });
</script>

</body>

</html>


<?php

if (isset($_FILES['file'])) {
  // Check if the "image" folder exists, create it if not
  $imageFolder = 'image';
  if (!is_dir($imageFolder)) {
    mkdir($imageFolder, 0777, true);
  }

  $fileName = $_FILES['file']['name'];


  $target = $imageFolder . '/' . $fileName;

  $counter = 1;
  while (file_exists($target)) {
    $target = $imageFolder . '/' . pathinfo($fileName, PATHINFO_FILENAME) . '_' . $counter . '.' . pathinfo($fileName, PATHINFO_EXTENSION);
    $counter++;
  }

  move_uploaded_file($_FILES['file']['tmp_name'], $target);
} else {
  echo '';
}
?>