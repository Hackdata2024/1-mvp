<?php
$snudataPath = 'snudata/'; // Change this to the actual path of your snudata folder

// Check if the snudata folder exists
if (is_dir($snudataPath)) {
    // Open the snudata folder
    $snudata = opendir($snudataPath);

    // Initialize an array to store folder names
    $folderNames = [];

    // Read all entries in the snudata folder
    while (($folder = readdir($snudata)) !== false) {
        // Exclude '.' and '..' entries
        if ($folder != '.' && $folder != '..') {
            // Add the folder name to the array
            $folderNames[] = $folder;
        }
    }

    // Close the snudata folder
    closedir($snudata);

    // Output the array as JSON
    header('Content-Type: application/json');
    echo json_encode($folderNames);
} else {
    // Output an error message if the snudata folder does not exist
    echo json_encode(['error' => 'The snudata folder does not exist.']);
}
?>
