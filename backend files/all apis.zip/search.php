<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Folder List</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.9/vue.min.js"></script>
    <style>
        html, body {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  margin-top: 16px;
  margin-bottom: 16px;
}

html{
    background: linear-gradient(to right, rgb(107,68,253), rgb(241,41,78));
}
div#app {
   
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
div#app .search-wrapper {
  position: relative;
}
div#app .search-wrapper label {
  position: absolute;
  font-size: 12px;
  color: #fff;
  top: 8px;
  left: 12px;
  z-index: -1;
  transition: 0.15s all ease-in-out;
}
div#app .search-wrapper input {
  padding: 10px 55px;
  color: rgba(0, 0, 0, 0.7);
  border: 2px solid rgba(0, 0, 0);
  border-radius: 20px;
  transition: 0.15s all ease-in-out;
  background: white;
}
div#app .search-wrapper input:focus {
  outline: none;
  transform: scale(1.05);
}
div#app .search-wrapper input:focus + label {
  font-size: 10px;
  transform: translateY(-24px) translateX(-12px);
}
div#app .search-wrapper input::-webkit-input-placeholder {
  font-size: 12px;
  color: rgba(0, 0, 0, 0.5);
  font-weight: 100;
}
div#app .wrapper {
  display: flex;
  max-width: 300px;
  flex-wrap: wrap;
  padding-top: 12px;
}
div#app .card {
  box-shadow: rgba(0, 0, 0, 0.117647) 0px 1px 6px, rgba(0, 0, 0, 0.117647) 0px 1px 4px;
  max-width: 124px;
  background-color: white;
  border-radius: 20px;
  margin: 12px;
  transition: 0.15s all ease-in-out;
}
div#app .card:hover {
  transform: scale(1.1);
}
div#app .card a {
  text-decoration: none;
  padding: 12px;
  color: #03A9F4;
  font-size: 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
div#app .card a img {
  height: 100px;
}
div#app .card a small {
  font-size: 10px;
  padding: 4px;
}
div#app .hotpink {
  background: hotpink;
}
div#app .green {
  background: green;
}
div#app .box {
  width: 100px;
  height: 100px;
  border: 1px solid rgba(0, 0, 0, 0.12);
}
.gif{
    display: grid;
    place-items: center;
    
}
.gif img{
    width: 70%;
    height: 70px;
    
}
div#app .maingif
{
    background-color: #fff;
    border-radius: 40px;
    margin-bottom: 20px;
    width: 80%;
}
    </style>
</head>
<body>


<div id="app">
    <div class="maingif">
    <div class="gif"><img src="ani.gif" alt=""></div></div>
   
  <div class="search-wrapper">
    <input type="text" v-model="search" placeholder="Search title.."/>
    <label>Search title:</label>
  </div> 
  <div class="wrapper">
    <div class="card" v-for="post in filteredList" :key="post.folder">
      <a v-bind:href="post.link" target="_blank">
        <img v-bind:src="post.img"/>
        <small style="color: #6C43FB;"> {{ post.author }}</small>
        {{ post.title }}
      </a>
    </div>
  </div>

</div>
<script>
class Post {
  constructor(title, link, author, img, folder) {
    this.title = title;
    this.link = link;
    this.author = author;
    this.img = img;
    this.folder = folder;
  }
}

const app = new Vue({
  el: '#app',
  data: {
    search: '',
    postList: []
  },
  computed: {
    filteredList() {
      return this.postList.filter(post => {
        return post.title.toLowerCase().includes(this.search.toLowerCase());
      });
    }
  },
  mounted() {
    // Fetch folder names using PHP and create posts dynamically
    this.fetchFolderNames();
  },
  methods: {
    fetchFolderNames() {
      // Make an AJAX request to get folder names from PHP
      // Replace the URL with the actual PHP script that retrieves folder names
      fetch('script.php')
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          // Create a post for each folder name
          this.postList = data.map(folder => {
            return new Post(
              folder,
              'https://twis.in/shop/apis/snudata/' + folder + '/index.php',
              'Void User', // You can set a default author or retrieve from PHP
              'img.jpg', // Provide a placeholder image or retrieve from PHP
              folder
            );
          });
        })
        .catch(error => {
          console.error('Error fetching folder names:', error);
        });
    }
  }
});
</script>

</body>
</html>