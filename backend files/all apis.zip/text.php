<?php

if (isset($_POST['textData'])) {
    $textData = $_POST['textData'];
    
    // Create the snudata directory if it doesn't exist
    $snudataDir = 'snudata';
    if (!is_dir($snudataDir)) {
        mkdir($snudataDir);
    }

    // Create a folder with the same name as the string received
    $folderPath = $snudataDir . '/' . $textData;

    if (!is_dir($folderPath)) {
        mkdir($folderPath);

        // Copy the index.php file to the newly created folder
        $indexFilePath = $folderPath . '/index.php';

        if (copy('index.php', $indexFilePath)) {
            echo "Folder and file created successfully. Text data: " . $textData;
        } else {
            echo "Error copying index.php to the folder.";
        }
    } else {
        echo "Folder already exists. Text data: " . $textData;
    }

    // Save text data to debug.txt and text.json as before
    $data = array(
        'text' => $textData
    );

    $jsonString = json_encode($data, JSON_PRETTY_PRINT);
    $debugFilePath = 'debug.txt';
    file_put_contents($debugFilePath, $textData . PHP_EOL, FILE_APPEND);
    $jsonFilePath = $folderPath . '/text.json';

    if (file_put_contents($jsonFilePath, $jsonString) !== false) {
        echo " Text data saved to JSON file.";
    } else {
        echo " Error saving text data to JSON file.";
    }
} else {
    echo "No text data received.";
}
?>
