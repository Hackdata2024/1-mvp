<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://s.codepen.io/assets/libs/modernizr.js"></script>
    <link rel="stylesheet" href="https://codepen.io/kjbrum/pen/myyZLq.scss">
    <style>
        @import url(https://fonts.googleapis.com/css?family=Open+Sans:400|Raleway:300);
html {
  padding-top: 50px;
  font-family: "Open Sans", Helvetica, arial, sans-serif;
  text-align: center;
  background-color: #eeeeee;
}
html *,
html *:before,
html *:after {
  box-sizing: border-box;
  transition: 0.5s ease-in-out;
}
html i, html em,
html b, html strong,
html span {
  transition: none;
}

*:before,
*:after {
  z-index: -1;
}

h1,
h4 {
  font-family: "Raleway", "Open Sans", sans-serif;
  margin: 0;
  line-height: 1;
}

a {
  text-decoration: none;
  line-height: 80px;
  color: black;
}

.centerer {
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
  padding: 0 1rem;
}

@media (min-width: 100%) {
  .wrap {
    display: grid;
    place-items: center;
    margin: auto;
    width: auto;
    float: left;

}
}
[class^=btn-] {
  position: relative;
  display: block;
  overflow: hidden;
  width: 100%;
  height: 80px;
  max-width: 250px;
  margin: 1rem auto;
  text-transform: uppercase;
  border: 1px solid currentColor;
}

.btn-0 {
  color: #742bbc;
}
.btn-0:before {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: #37046a;
  transform: translateX(-100%);
}
.btn-0:hover {
  color: #d6c1eb;
}
.btn-0:hover:before {
  transform: translateX(0);
}

.btn-1 {
  color: #447480;
}
.btn-1:before {
  content: "";
  position: absolute;
  top: 0;
  right: -50px;
  bottom: 0;
  left: 0;
  border-right: 50px solid transparent;
  border-bottom: 80px solid #15373f;
  transform: translateX(-100%);
}
.btn-1:hover {
  color: #c8d6da;
}
.btn-1:hover:before {
  transform: translateX(0);
}
.logo{
    width: 60%;
    height: 100px;
}

    </style>
</head>
<body>
<div class="centerer">
    <img class="logo" src="logo.gif" alt="">
  <h1>Admin Panel</h1>


  <div class="wrap">
    <a class="btn-0" href="https://twis.in/shop/backend-img/">Advertisment Management</a>
    <a class="btn-1" href="https://hackdata.twis.in/wp-admin/admin.php?page=wc-orders">View Orders</a>

  </div>
</div>
<script>
    $(function() {  
  $('.btn-6')
    .on('mouseenter', function(e) {
			var parentOffset = $(this).offset(),
      		relX = e.pageX - parentOffset.left,
      		relY = e.pageY - parentOffset.top;
			$(this).find('span').css({top:relY, left:relX})
    })
    .on('mouseout', function(e) {
			var parentOffset = $(this).offset(),
      		relX = e.pageX - parentOffset.left,
      		relY = e.pageY - parentOffset.top;
    	$(this).find('span').css({top:relY, left:relX})
    });
});

</script>
</body>
</html>