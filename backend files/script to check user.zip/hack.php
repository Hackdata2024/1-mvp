<?php
// Function to check if the username already exists in the JSON file
function isUsernameExists($username, $data) {
    foreach ($data as $user) {
        if ($user['name'] === $username) {
            return true;
        }
    }
    return false;
}

// Read existing data from the JSON file
$jsonFile = 'usernames.json';
$data = [];

if (file_exists($jsonFile)) {
    $jsonContent = file_get_contents($jsonFile);
    $data = json_decode($jsonContent, true);
}

// Check if a username is provided through POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = $_POST['username'];

    // Check if the username already exists
    if (isUsernameExists($username, $data)) {
        echo "Username already exists.";
    } else {
        $newUser = ['name' => $username];
        $data[] = $newUser;

        // Save the updated data to the JSON file
        file_put_contents($jsonFile, json_encode($data));

        // Display a single message for both cases
        echo "Username saved successfully.";
    }
}
?>
